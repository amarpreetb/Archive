#include <stdio.h>
int main(void) {
   int i = 3; int j = 1;
   printf("<<%dD %dU!\rGO\n", --j,++i);
   return 0;
}
/*
GO0D 4U!
*/
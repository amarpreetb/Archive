# IPC-SRR-Notes

## Visual Studio
[How to download and install Visual Studio](https://www.youtube.com/watch?v=xMGhA5v4vxk)<br />
[How to create a simple console application in Visual studio](https://www.youtube.com/watch?v=6siQm1sIu5g) <br />

## Coding Style:
When writing your code you are not allowed to have tab character in your C code; this is how to convert tab to code in VI and Vistual studio and codelite: <br />
[Converting tab to spaces in VI](http://vim.wikia.com/wiki/Converting_tabs_to_spaces) (thank you Peter Heng, OOP244SAB)<br />
[Converting tab to spaces in Visual Studio](https://www.youtube.com/watch?v=oW4viEA72UI)<br />
[Converting tab to spaces in Codelite](https://www.youtube.com/watch?v=XQMPJpA8fJI&t)<br />
If you know how to do this in any other editor or IDE, please email me the resource and I will add it here.

## Lecture Videos:
[03 - Jan 16, week 1 and 2](https://www.youtube.com/watch?v=Hh14pcGofCA)<br />
[05 - Jan 23, week 3](https://www.youtube.com/watch?v=lZy38BzFMS8)<br />
[07 - Jan 30, week 4](https://www.youtube.com/watch?v=d9vUNAA537E)<br />

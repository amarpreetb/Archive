//1- determine the exact output of the following program [2 marks]
#include <stdio.h>
int main(void){
   printf(" his\b\bat is a test \rT\nFor \"U\" and \that is mine");
   return 0;
}


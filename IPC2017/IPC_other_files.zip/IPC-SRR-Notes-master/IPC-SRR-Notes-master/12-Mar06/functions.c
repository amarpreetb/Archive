output FunctionName(input1, input2, .....intputN)

int subtract(int num1, int num1);

void print(int num);

double doubleTheValue(double a);

glove MakeGlove(leather L);

//improtant ones:

void bar(int size);
int ReadInt();
int ReadLimited(int max);
int ReadMinMax(int min, int max);
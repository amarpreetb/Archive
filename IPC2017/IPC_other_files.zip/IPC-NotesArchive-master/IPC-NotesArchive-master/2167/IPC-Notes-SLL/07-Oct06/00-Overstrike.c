#include <stdio.h>
int main(void) {
   int area;
   int exch;
   int num;
   printf("                    --- --- ----\r");
   printf("Enter Phone number: ");
   scanf("%d %d %d", &area, &exch, &num);
   return 0;
}
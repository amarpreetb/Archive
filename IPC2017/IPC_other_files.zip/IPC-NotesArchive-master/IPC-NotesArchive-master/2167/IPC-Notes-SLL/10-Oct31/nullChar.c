
#include <stdio.h>

int main(void) {
   char ch = '0';
   printf("%c %d\n", ch, ch);
   ch = 0;
   printf("%c %d\n", ch, ch);

   return 0;
}

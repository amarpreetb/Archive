/* this is the first prog for ipc144s*/
#include <stdio.h>
int main(){
   printf("Hello there!\n"); // printing hello there on the screen 
   return 0;
}
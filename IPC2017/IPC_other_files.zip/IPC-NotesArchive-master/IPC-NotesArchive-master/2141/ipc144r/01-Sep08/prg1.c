/*
this is the first program in ipc144
*/
#include <stdio.h>
int main(){
   printf("Hello there!\n");    // printf is a function in stdio.h, and prints stuff on the screen
   return 0;  /* returns zero to OS */
}
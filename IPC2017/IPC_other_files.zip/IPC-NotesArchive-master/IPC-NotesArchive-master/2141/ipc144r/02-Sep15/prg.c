#include <stdio.h>
int main(){
   int
      age = 48;
   double
      salary = 123456.78;
   /*   printf("format", variables, ....);
   place holders:
   decimal   %d
   double    %lf

   */

   printf("I am %d years old and I make %lf dollars\n", age, salary);
   return 0;
}

#include <stdio.h>
int main(){
   char  a, b, c, d;  /* bad style, not in my class*/
   int i, j;
   int k = 5, l;
   const double pi = 3.14159265;

   return 0;
}
#include <stdio.h>
int main() {
   printf("Hello IPC144SRR\n");
   return 0;
}
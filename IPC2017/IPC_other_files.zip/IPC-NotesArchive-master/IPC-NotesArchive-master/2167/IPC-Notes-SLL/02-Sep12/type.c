#include <stdio.h>
int main(void) {
   int number;
   number = 10;
   printf("%d\n", number);
   return 0;
}
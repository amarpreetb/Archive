#ifndef ___TOOLS_H___
#define ___TOOLS_H___

void keyflush();



#endif
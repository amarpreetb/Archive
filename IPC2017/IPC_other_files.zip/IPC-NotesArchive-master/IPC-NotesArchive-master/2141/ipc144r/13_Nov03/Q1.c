#include <stdio.h>
int main(){
   char
      name[10];
   name[0] = 'F';
   name[1] = 'a';
   name[2] = 'r';
   name[3] = 'd';
   name[4] = 'a';
   name[5] = 'd';
   name[6] = 0;
   printf(name);
   return 0;
}
#include <stdio.h>

int main(){
   int
      age;
   printf("What is your age? ");
   scanf("%d", &age);
   printf("you are %d years old!\n", age);
	return 0;
}

int foo(int a){
   return a * 3;
}
# Submitter
A program to help submit student work on a linux server<br />
To use this, clone it on your linux machine, <br />
<pre>
$ git clone https://github.com/fardad/Submitter.git
$ cd Submitter
$ chmod 700 install
$ install
</pre>

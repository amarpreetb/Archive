// this is not tested , may have bugs
// V1.0
#ifndef _FS_TOOLS_H_
#define _FS_TOOLS_H_

void keybFlush();
int getInt();
double getDouble();
int getLimInt(int lowerLimit, int upperLimit);
double getLimDbl(double lowerLimit, double upperLimit);
int yes();

#endif
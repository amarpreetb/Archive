#include <stdio.h>
int main(){
   char
      ch = 65;
   putchar(ch);
   ch = ch + 3;
   putchar(ch);
   return 0;
}


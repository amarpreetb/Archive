#include <stdio.h>
int main() {
   int num;
   int counter ;


   counter = 0;
   while (counter < num) {
      // body
      counter++;
   }

   for (counter = 0; counter < num; counter++) {
      // body
   }


   printf("The sum is: %lf\n", sum);
   printf("Done!\n");
   return 0;
}
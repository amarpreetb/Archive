#include <stdio.h>
int main() {
   printf("%u\n", sizeof(int));
   printf("%u\n", sizeof(short));
   printf("%u\n", sizeof(long long));
   return 0;
}
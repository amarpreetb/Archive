#ifndef ___MYTOOLS_H___
#define ___MYTOOLS_H___


void keyflush();



#endif
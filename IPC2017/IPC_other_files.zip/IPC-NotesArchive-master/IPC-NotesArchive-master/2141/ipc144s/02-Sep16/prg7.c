#include <stdio.h>
int main(){
   int
      ch;
   ch = 'A';
   putchar(ch);
   ch = ch + 3;
   putchar(ch);
   return 0;
}
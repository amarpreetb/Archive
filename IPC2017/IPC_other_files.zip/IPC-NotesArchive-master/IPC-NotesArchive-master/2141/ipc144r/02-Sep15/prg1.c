#include <stdio.h>
/* proper style of declration*/
int main(){
   char      /* variable declration; type and then the variable name */
      ch;    /* on the next line.                                    */
   int
      i;
   int
      j;
   int
      k;
   ch = 65;
   i = 10;
   i = i + 1;
   /* here the value of i is 11*/
   i = ch + 10;
   /* here the value of i is 75*/
   return 0;
}
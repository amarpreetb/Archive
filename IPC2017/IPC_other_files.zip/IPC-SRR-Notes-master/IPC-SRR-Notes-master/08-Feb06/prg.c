#include <stdio.h>
struct Marks {
   int stno;
   int ipc;
   int uli;
   int apc;
   int cpr;
};

struct CharCode {
   int code;
   char ch;
};


int main() {
   struct Marks A, B;
   A.ipc = 100;
    = 90;
   int a;
   scanf("%d", &B.ipc);
   return 0;
}
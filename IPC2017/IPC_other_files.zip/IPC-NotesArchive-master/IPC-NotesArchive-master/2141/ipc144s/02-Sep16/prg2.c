#include <stdio.h>
int main(){
   char ch;  /* bad for your health, don't write like this*/
   int i, j, k, l;
   long bigI;
   return 0;
}
#include <stdio.h>
int main(){
   char
      ch;
   ch = 0x41;
   putchar(ch);
   ch = ch + 3;
   putchar(ch);
   return 0;
}
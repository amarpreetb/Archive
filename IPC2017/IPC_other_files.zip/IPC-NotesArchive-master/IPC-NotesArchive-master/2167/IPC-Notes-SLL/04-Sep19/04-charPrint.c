#include <stdio.h>
int main(void) {
   char ch = 65;
   printf("Char: %c  code in int: %d, code in Hex: %X\n", ch, ch, ch);
   return 0;
}
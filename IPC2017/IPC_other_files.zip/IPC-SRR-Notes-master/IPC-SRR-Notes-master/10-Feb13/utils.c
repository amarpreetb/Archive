int add(int a, int b) {
   int res;
   res = a + b;
   return res;
}
double findMax(double a, double b) {
   double max;
   if (a > b) max = a;
   else max = b;
   return max;
}
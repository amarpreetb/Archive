// -------------------------------------------
//  Name:
//  ID:
//  Email:
//  Description: Milestone #3
// -------------------------------------------

#include <stdio.h>

// Copy your milestone #2 source code below
// - Add new function prototypes and definitions
//   for milestone #3 as per the directions


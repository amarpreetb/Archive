
void keyflush(){
   char
      ch;
   do{
      ch = getchar();
   } while (ch != '\n');
}
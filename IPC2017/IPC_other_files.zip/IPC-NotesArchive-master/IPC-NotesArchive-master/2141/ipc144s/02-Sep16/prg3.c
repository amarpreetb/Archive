#include <stdio.h>
int main(){
   char
      ch;
   /*ch = 65; */
   /*ch = 0x41;*/
   ch = 0101;  /*oct notation that is 65 which is code for A*/
   putchar(ch);
   return 0;
}
#include <stdio.h>
int main(void) {
   printf("abc\rdef\tg\thijk\nlmno\"pqrst\auv\"wx\byz\n");
   return 0;
}
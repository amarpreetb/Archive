# IPC-Notes-SLL
## List of lecture videos:
* [Sep08](https://www.youtube.com/watch?v=CMs2T_FzbDg)
* [Sep12](https://www.youtube.com/watch?v=C9_bq-UaX0A) Unfortunately the audio of this lecture is not recorded. I don’t think It is worth watching!!!!
* [Sep19](https://www.youtube.com/watch?v=kC6oDDKyxR4)
* [Sep26](https://www.youtube.com/watch?v=P1GYweLRkN8)
* [Oct03p1](https://www.youtube.com/watch?v=wVgksyOEYU4)
* [Oct03P2](https://www.youtube.com/watch?v=Dx66nmklz_U)
* [Oct13P1](https://www.youtube.com/watch?v=xgw0TtScypk)
* [Oct13P2](https://www.youtube.com/watch?v=z840If3YjMk)
* [Oct13P3](https://www.youtube.com/watch?v=BaXvLZ5QR-g)
* [Oct17](https://www.youtube.com/watch?v=xXvAVwtS-V4)
* [Oct31](https://www.youtube.com/watch?v=4Vi87BxDEGw)



#include <stdio.h>
int main(){
   char   /* the good style*/
      ch;
   int
      i;
   int
      j;
   long
      bigI;
   double
      d;
   return 0;
}
// -------------------------------------------
//  Name:
//  ID:
//  Email:
//  Description: Milestone #4
// -------------------------------------------

#include <stdio.h>

// Copy your milestone #3 source code below
// - Add new function prototypes and definitions
//   for milestone #4 as per the directions


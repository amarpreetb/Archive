#include "Submitter.h"

int main(int argc, char* argv[]){
  sict::Submitter S(argc, argv);
  return S.run();
}
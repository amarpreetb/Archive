// -------------------------------------------
//  Name:
//  ID:
//  Email:
//  Description: Milestone #2
// -------------------------------------------

#include <stdio.h>

// Copy your milestone #1 source code below
// - Add new function prototypes and definitions
//   for milestone #2 as per the directions


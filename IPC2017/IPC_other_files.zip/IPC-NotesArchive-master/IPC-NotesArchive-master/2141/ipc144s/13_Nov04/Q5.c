double min(double a, double b){
   int min = a;
   if (a > b)
      min = b;
   return min;
}
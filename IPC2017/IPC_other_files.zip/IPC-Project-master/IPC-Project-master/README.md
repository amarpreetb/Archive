# IPC-Project

**IMPORTANT DATES:**

* Milestone - 1:     Due on **July 4**, 2017
* Milestone - 2:     Due on **July 13**, 2017
* Milestone - 3:     Due on **July 25**, 2017
* Milstonee - 4:     Due on **August 9**, 2017

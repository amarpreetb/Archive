void keyflush(){
   char
      ch;
   do{
      ch = getchar();
      //scanf("%c", &ch);
   }while(ch != '\n');
}

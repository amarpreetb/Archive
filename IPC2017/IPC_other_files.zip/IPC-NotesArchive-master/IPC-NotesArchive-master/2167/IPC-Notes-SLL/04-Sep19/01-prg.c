#include <stdio.h>
int main(void) {
   char i;
   short j;
   int k;
   long l;
   float f;
   double d;
   long double g;
   return 0;
}
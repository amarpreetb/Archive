#include <stdio.h>
int main() {
   printf("Hello VS!\n");
   printf("Hello VS!\n");
   printf("Hello VS!\n");
   printf("Hello VS!\n");
   printf("Hello VS!\n");
   printf("Hello VS!\n");
   printf("Hello VS!\n");
   return 0;
}
